############################################
#
#            	MESH SEPARATOR SCRIPT
#
#You can use, share and modify this script as you want, just always remind the author(me).
#
#This script splits the mesh of an object in many squares.
#I have wrote this in order to split terrain meshes for my dynamic loading terrain script.
#
#
#At first i did this with python, but was orribly slow and memory consuming(on my notebook it crashed if the vertices were over 1000)
#
#So i wrote it in C, and made the python script "interface" with the C program.
#Now it can handle more than 64000 vertices(i did't tryed it, but i think the script 
#can easly go over a milion vertices, but the time it will require will grow a lot) and
# separe the mesh in less then 2 minutes(on a notebook).
#You'll find the C source commented at the end of this script.
#
#Since i put a lot of effort in doing this, if you have good tips, bugs, or sugestions
#(if supported with code, or an idea on how to solve/add them is even better) i'll really 
#appreciate if you mail me at makers.f (at) gmail (dot) com
#
#If you use it to get nice results, please mail me too, so i'll see if my work is usefeul ;)
#
#
#I'm still working on this, so when i'll have time(the university consume it a lot)
#i'll make it multithread so that the multicore processors will go from 2 to 8 time faster(based
#on how many thread you can compute at the same time)
#
#By Francesco Zoffoli(aka Makers_F)
############################################


import bpy
from bpy.props import IntProperty
from math import pow
import os

def separemesh(context, function, size):
 #starting infos
 passatr=str(function) + " " + str(len(bpy.context.active_object.data.vertices)) + " " + str(size)
 
 #add the infos of all vertices(z vertex is unused, so it can be removedo, but ONLY IF DONE IN THE C PROGRAM TOO
 for v in bpy.context.active_object.data.vertices:
  passatr+=" " + str(v.index) + " " + str(v.co[0])+ " " + str(v.co[1])+ " " + str(v.co[2])
 
 

 #write infos to file
 path="testo.txt"
 f=open(path,"w")
 f.write(passatr)
 f.close
 
 #delete the variable now useless(save memory)
 del passatr
 #run the C program
 os.system("FaceDividerFile.exe " + path)
 
 if function==2:
  #get the infos given by the c program
  f=open("square_list.txt","r")
  list=[]
  nl=f.readline()
  while(nl!=''):
   list.append(int(nl))
   nl=f.readline()
  
  f.close()
  
  #deselect al vertices
  bpy.ops.object.mode_set(mode='EDIT')
  bpy.ops.mesh.select_all(action='DESELECT')
  bpy.ops.object.mode_set(mode='OBJECT')
  
  #select the useful vertices
  for i in list:
   bpy.context.active_object.data.vertices[i].select = True
  
  bpy.ops.object.mode_set(mode='EDIT')
  bpy.ops.mesh.separate(type="SELECTED")
  bpy.ops.object.mode_set(mode='OBJECT')
  return
 
 if function==1:
  f=open("max_min.txt","r")
  lower=int(f.readline())
  highter=int(f.readline())
  f.close()
  return [lower,highter]
  
  
  
class separeMesh(bpy.types.Panel):
 bl_label= "Separe Mesh"
 bl_space_type = "VIEW_3D"
 bl_region_type = "UI"
 
 '''
 #property(commented becouse it doesn't work..)
 bpy.context.scene.sideprop = IntProperty(name="Square Side", description="The lengh of the square side", min=2, max=5, default=4)
 '''
 
 @classmethod
 #only if the object selected is a mesh object the menu will be displayed
 def poll(self, context):
  if context.object and context.object.type == "MESH":# and context.object.mode== "EDIT":
   return 1

 
 
 def draw(self, context):
  layout = self.layout
  box = layout.box()
  row = box.row(align=False)
  '''
  row.prop(bpy.context.scene, 'sideprop')
  '''
  
  row=box.row(align=False)
  row.operator("object.SepareMesh")
  

class OBJECT_OT_SepareMesh(bpy.types.Operator):
 bl_idname = "OBJECT_OT_SepareMesh"
 bl_label = "Separe"
 context=bpy.context
 #obj_act=context.active_object
 #data_ob=bpy.context.active_object.data.vertices
 
 def execute(self, context):
  import bpy
  
  print("Esecuzione")
  
  size=2 #set it with prop(now that doesn't work...)
  size=pow(size,2)
  
  lower = separemesh(context,1,size)
  highter = lower[1]
  lower = lower[0]
  
  tiles = round((round(bpy.context.active_object.data.vertices[highter].co[0] - bpy.context.active_object.data.vertices[lower].co[0]) * round(bpy.context.active_object.data.vertices[highter].co[1] - bpy.context.active_object.data.vertices[lower].co[1]))/size)+1
  
  print("The mesh will be divided in " + str(tiles) + " objects")
  for i in range(tiles):
   separemesh(context,2,size)
   print(str(i+1) + " separated\n")
  
  os.remove("testo.txt")
  os.remove("square_list.txt")
  os.remove("max_min.txt")
  print("Finito")
  return{'FINISHED'}
 
  
 



#Here you are the C code

'''
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

typedef struct{
    int index;
    float x,y,z;
} vertex;

vertex *find_vertex(vertex *list, int len)
{
    int i;
    vertex lower,highter;
    lower=list[0];
    highter=list[1];
    for(i=0;i<len;i++)
    {
        if ((list[i].x<=lower.x) && (list[i].y<=lower.y))
            lower=list[i];
        if ((list[i].x>=highter.x) && (list[i].y>=highter.y))
            highter=list[i];
    }
    vertex *ret;//create a pointer to return(it's not possible to return array)
    ret=(vertex*)malloc(sizeof(vertex)*2);
    if (ret==NULL)
    {
        printf("Can't allocate the memory");
		system("pause");
        return 0;
    }
    ret[0]=lower;
    ret[1]=highter;
    return ret;
}

vertex *square_list_of_vertex(vertex *list,int len,vertex start, float size)
{
    int i=0,a=0;
    unsigned int *num;
    num=(int*)malloc(sizeof(unsigned int)*len);
    if (num==NULL)
    {
        printf("Can't allocate the memory");
		system("pause");
        return 0;
    }
    //controlls which points are in the right position and adds their main list's index in another list
    for(i=0;i<len;i++)
    {
        if ((list[i].x-start.x)<size && (list[i].y-start.y<size))
        {
            if (list[i].y-start.y>-size/100)
            {
                num[a]=i;
                a++;//len of the return list
            }
        }
    }
    
    //create the list with the right vertices
    vertex *retlist;
    retlist=(vertex*)malloc(sizeof(vertex)*(a+1));
    if (retlist==NULL)
    {
        printf("Can't allocate the memory");
		system("pause");
        return 0;
    }
    //the first index is used only as an info container
    vertex infos;
    infos.index=a+1;
    retlist[0]=infos;
    
    //set the value for the return pointer
    for(i=1;i<=a;i++)
    {
        retlist[i]=list[num[i-1]];
    }
    
    return retlist;
}

//the function that pass the data to python
void return_funct_1(vertex lower,vertex highter)
{
    FILE* ret;
    ret=fopen("max_min.txt","w");
    
    fprintf(ret,"%i\n",lower.index);
    fprintf(ret,"%i\n",highter.index);
    fclose(ret);
}

//the function that pass the data to python
void return_funct_2(vertex *squarelist)
{
    FILE* ret;
    int i,len;
    ret=fopen("square_list.txt","w");
    len=squarelist[0].index;
    for(i=1;i<len;i++)
    {
        //return all the informations
        //fprintf(ret,"%i %f %f %f\n",squarelist[i].index,squarelist[i].x,squarelist[i].y,squarelist[i].z);
        
        //just return the index(it's enought for the python script
        fprintf(ret,"%i\n",squarelist[i].index);
    }
    fclose(ret);
}





//argv: path of the file
int main(int argc, char *argv[])
{
    if(argc==1)
    {
        printf("%s need a path to a vectorlist file\n",argv[0]);
		system("pause");
        return 0;
    }
    FILE* input;
    input=fopen(argv[1],"r");
    if (input==NULL)
    {
        printf("Error opening the file\n");
		system("pause");
        return(0);
    }
    int func=0,i=0,a=0,u=0;
    char read;
    char* argument;
    argument=(char*)malloc(sizeof(char)*50);//i don't think the program will be used with more than 10^50 -1 vertices
    
    //get the first paramater in the file
    argument[0]=fgetc(input);
    argument[1]='\0';
    func=atoi(argument);
    
    //skipp the space
    read=fgetc(input);
    
    //get the number of vertices;
    i=0;
    do {
        read=fgetc(input);
        argument[i]=read;
        i++;
    }while(read!=' ' && !feof(input) );
    //set the end of the string
    argument[i]='\0';
    
    //set the variable to the correct integer value;
    int vnumber=atoi(argument);
    
    i=0;
    do {
        read=fgetc(input);
        argument[i]=read;
        i++;
    } while(read!=' ' && !feof(input));
    //set the end of the string
    argument[i]='\0';
    float sqsize=atof(argument);
    
    vertex *list;
    //allocate memory in the array to fit the number of vertex needed
    list=(vertex*)malloc(sizeof(vertex)*vnumber);
    
    //control if the memory get allocated
    if (list==NULL)
    {
        printf("Can't allocate the memory");
		system("pause");
        return 0;
    }
    
    //do the cycle for each vertex
    for(u=0;u<vnumber;u++)
    {
        //read the number and assign it to the proper value of the vertex
        for(a=0;a<4;a++)
        {
            i=0;
            do
            {
                read=fgetc(input);
                argument[i]=read;
                i++;
            } while(read!=' ' && !feof(input));
            argument[i]='\0';
            
            if(a==0)
                list[u].index=atoi(argument);
            if(a==1)
                list[u].x=atof(argument);
            if(a==2)
                list[u].y=atof(argument);
            if(a==3)
                list[u].z=atof(argument);
        }
        //printf("%i, %f, %f, %f\n",list[u].index,list[u].x,list[u].y,list[u].z);
    }
    
    //close the file
    fclose(input);
    
    if (func==1)
    {
        //let's find the lower and the highter
        //find the lowest vertex and the higtest vertex
        vertex lower,highter;
        vertex *lohi;
        lohi=(vertex*)find_vertex(list, vnumber);
        lower=lohi[0];
        highter=lohi[1];
        free(lohi);
        return_funct_1(lower,highter);//the function that return the data to python
    }
    
    if(func==2)
    {
        //find the list to return
        vertex *lohi;
        lohi=(vertex*)find_vertex(list, vnumber);
        vertex lower;
        lower=lohi[0];
        free(lohi);
        return_funct_2(square_list_of_vertex(list,vnumber, lower, sqsize));//the function that return the data to python
    }
    //system("pause");
}
'''