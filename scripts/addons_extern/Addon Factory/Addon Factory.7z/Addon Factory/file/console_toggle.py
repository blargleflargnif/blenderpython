import bpy
bpy.ops.wm.console_toggle()
