numexpr_available=False
try:
  import numexpr
  numexpr_available=True
except ImportError:
  pass

